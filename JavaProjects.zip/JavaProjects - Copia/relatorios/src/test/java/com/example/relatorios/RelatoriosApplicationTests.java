package com.example.relatorios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelatoriosApplicationTests {

	@Test
	void contextLoads() {
	}

}
