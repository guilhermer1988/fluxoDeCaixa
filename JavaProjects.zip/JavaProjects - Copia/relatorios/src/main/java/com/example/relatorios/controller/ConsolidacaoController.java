package com.example.relatorios.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.reactive.ReactorLoadBalancerExchangeFilterFunction;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.relatorios.model.Lancamento;
import com.example.relatorios.model.TipoLancamento;
import com.example.relatorios.repository.LancamentoRepository;
import com.example.relatorios.service.LancamentoService;

import reactor.core.publisher.Mono;

@RestController
public class ConsolidacaoController {
	@Autowired
    private WebClient.Builder loadBalancedWebClientBuilder;
    private LancamentoService _lancamentoService;
	
    public ConsolidacaoController(LancamentoService lancamentoService) {
    	this._lancamentoService = lancamentoService;
	}
    
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @GetMapping("/consolidacaoLoadBalance/{date}")
    public BigDecimal getSaldoConsolidadoLoadBalance(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        
    	return _lancamentoService.calculoConsolidado(date);
    }
    

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @GetMapping("/Consolidacao/{date}")
    public Mono<BigDecimal> getSaldoConsolidado(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        
    		return loadBalancedWebClientBuilder
    				.build()
    				.get()
    				.uri("http://localhost:8888/relatorios/consolidacaoLoadBalance/"+date)
    		        .retrieve()
    		        .bodyToMono(BigDecimal.class);
    }
    
    
}