package com.example.relatorios.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.relatorios.model.Lancamento;
import com.example.relatorios.model.TipoLancamento;
import com.example.relatorios.repository.LancamentoRepository;

@Service
@Transactional
public class LancamentoService {
	@Autowired
    private LancamentoRepository lancamentoRepository;

	public BigDecimal calculoConsolidado(LocalDate data) {
		LocalTime start = LocalTime.of(00, 00);
		LocalTime end = LocalTime.of(23, 59);	
		LocalDateTime localDateTimeStart = LocalDateTime.of(data, start);
		LocalDateTime localDateTimeEnd = LocalDateTime.of(data, end);
		List<Lancamento> lancamentos = lancamentoRepository.findByDataBetween(localDateTimeStart, localDateTimeEnd);
		
        // Calcula o saldo consolidado, somando créditos e subtraindo débitos
        BigDecimal saldoConsolidado = BigDecimal.ZERO;

        for (Lancamento lancamento : lancamentos) {
            if (lancamento.getTipo() == TipoLancamento.CREDITO) {
                saldoConsolidado = saldoConsolidado.add(lancamento.getValor());
            } else if (lancamento.getTipo() == TipoLancamento.DEBITO) {
                saldoConsolidado = saldoConsolidado.subtract(lancamento.getValor());
            }
        }

        return saldoConsolidado;
	}
}
