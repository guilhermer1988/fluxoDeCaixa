package com.example.relatorios.model;

public enum TipoLancamento {
	DEBITO,
    CREDITO
}
