package com.example.relatorios.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.relatorios.model.Lancamento;

@Repository
public interface LancamentoRepository extends JpaRepository<Lancamento, Long> {
    List<Lancamento> findByData(LocalDateTime data);
    List<Lancamento> findByDataBetween(LocalDateTime start, LocalDateTime end);
}
