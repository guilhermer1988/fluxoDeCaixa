package com.example.lancamentos.controller;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lancamentos.model.Lancamento;
import com.example.lancamentos.repository.LancamentoRepository;
import com.example.lancamentos.service.LancamentoService;

@RestController
public class LancamentoController {
	
    private LancamentoRepository _lancamentoRepository;
    
    private LancamentoService _lancamentoService;
    
    public LancamentoController(LancamentoRepository lancamentoRepository,
    		LancamentoService lancamentoService) {
        this._lancamentoRepository = lancamentoRepository;
        this._lancamentoService = lancamentoService;
    }

    // POST /lancamentos: Cria um novo lançamento
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @PostMapping("/Lancamento")
    public ResponseEntity<Lancamento> criarLancamento(@RequestBody Lancamento lancamento) {
    	lancamento.setData(LocalDateTime.now());
        Lancamento novoLancamento = _lancamentoService.createLancamento(lancamento);
        return ResponseEntity.ok(novoLancamento);
    }

    // PUT /lancamentos/{id}: Atualiza um lançamento existente
    @PutMapping("/{id}")
    public ResponseEntity<Lancamento> atualizarLancamento(@PathVariable Long id, @RequestBody Lancamento lancamento) {
        Optional<Lancamento> lancamentoExistente = _lancamentoRepository.findById(id);

        if (lancamentoExistente.isPresent()) {
            Lancamento lancamentoAtualizado = _lancamentoService.updateLancamento(lancamentoExistente.get());
            return ResponseEntity.ok(lancamentoAtualizado);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE /lancamentos/{id}: Exclui um lançamento
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirLancamento(@PathVariable Long id) {
        Optional<Lancamento> lancamentoExistente = _lancamentoRepository.findById(id);

        if (lancamentoExistente.isPresent()) {
        	_lancamentoRepository.delete(lancamentoExistente.get());
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // GET /lancamentos/{id}: Consulta um lançamento específico
    @GetMapping("/{id}")
    public ResponseEntity<Lancamento> consultarLancamento(@PathVariable Long id) {
        Optional<Lancamento> lancamento = _lancamentoRepository.findById(id);

        if (lancamento.isPresent()) {
            return ResponseEntity.ok(lancamento.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
