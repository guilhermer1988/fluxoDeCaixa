package com.example.lancamentos.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.lancamentos.model.Lancamento;
import com.example.lancamentos.repository.LancamentoRepository;

@Service
@Transactional
public class LancamentoService {

	@Autowired
    private LancamentoRepository lancamentoRepository;

	public Lancamento createLancamento(Lancamento lancamento) {
		Lancamento novoLancamento = lancamentoRepository.save(lancamento);
        return novoLancamento;
	}
	
	public Lancamento updateLancamento(Lancamento lancamento) {
		Lancamento lancamentoAtualizado = lancamento;
        lancamentoAtualizado.setTipo(lancamento.getTipo());
        lancamentoAtualizado.setValor(lancamento.getValor());
        lancamentoAtualizado.setData(lancamento.getData());
        lancamentoAtualizado.setDescricao(lancamento.getDescricao());
        lancamentoRepository.save(lancamentoAtualizado);
        return lancamentoAtualizado;
	}

	public Lancamento getLancamentoById(long id) {
		Lancamento lancamentoExistente = lancamentoRepository.findById(id).get();
		return lancamentoExistente;
	}

	public List<Lancamento> getLancamentosByDate(LocalDate of) {
		// TODO Auto-generated method stub
		return null;
	}

}
