package com.example.lancamentos.model;

public enum TipoLancamento {
	DEBITO,
    CREDITO
}
