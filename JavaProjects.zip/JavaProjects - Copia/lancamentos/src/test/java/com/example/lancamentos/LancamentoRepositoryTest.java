package com.example.lancamentos;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import com.example.lancamentos.model.Lancamento;
import com.example.lancamentos.model.TipoLancamento;
import com.example.lancamentos.repository.LancamentoRepository;

class LancamentoRepositoryTest {

	@Autowired
    private TestEntityManager entityManager;

    @Autowired
    private LancamentoRepository lancamentoRepository;

    @BeforeEach
    public void setUp() {
        // Setup initial data for testing
        Lancamento lancamento1 = new Lancamento();
        lancamento1.setTipo(TipoLancamento.CREDITO);
        lancamento1.setValor(new BigDecimal(100.0));
        
        LocalDate date = LocalDate.of(2024, 8, 31);
        LocalTime time = LocalTime.of(21, 34);	
        LocalDateTime localDateTime = LocalDateTime.of(date, time);
        lancamento1.setData(localDateTime);
        lancamento1.setDescricao("Pagamento de Cliente");
        entityManager.persist(lancamento1);

        Lancamento lancamento2 = new Lancamento();
        lancamento2.setTipo(TipoLancamento.DEBITO);
        lancamento2.setValor(new BigDecimal(50.0));
        lancamento2.setData(localDateTime);
        lancamento2.setDescricao("Compra de material");
        entityManager.persist(lancamento2);
    }

    @Test
    public void testFindByData() {
    	
    	LocalDate date = LocalDate.of(2024, 8, 31);
        LocalTime time = LocalTime.of(21, 34);	
        LocalDateTime localDateTime = LocalDateTime.of(date, time);
        
        List<Lancamento> lancamentos = lancamentoRepository
        		.findByData(localDateTime);
        assertThat(lancamentos).hasSize(2);
    }

    @Test
    public void testSaveLancamento() {
        Lancamento lancamento = new Lancamento();
        lancamento.setTipo(TipoLancamento.CREDITO);
        lancamento.setValor(new BigDecimal(200.0));
        
        LocalDate date = LocalDate.of(2024, 9, 01);
        LocalTime time = LocalTime.of(21, 34);	
        LocalDateTime localDateTime = LocalDateTime.of(date, time);

        lancamento.setData(localDateTime);
        lancamento.setDescricao("Venda de produto");

        Lancamento savedLancamento = lancamentoRepository.save(lancamento);
        assertThat(savedLancamento.getId()).isNotNull();
    }
}
