package com.example.lancamentos;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.lancamentos.model.Lancamento;
import com.example.lancamentos.model.TipoLancamento;
import com.example.lancamentos.repository.LancamentoRepository;
import com.example.lancamentos.service.LancamentoService;

@SpringBootTest
class LancamentoServiceTest {

	    @Mock
	    private LancamentoRepository lancamentoRepository;

	    @InjectMocks
	    private LancamentoService lancamentoService;
	    
	    public LancamentoServiceTest() {
	        MockitoAnnotations.openMocks(this);
	    }

	    @Test
	    public void testCreateLancamento() {
	        Lancamento lancamento = new Lancamento();
	        lancamento.setTipo(TipoLancamento.CREDITO);
	        lancamento.setValor(new BigDecimal(150.0));
	        
	        LocalDate date = LocalDate.of(2024, 8, 31);
	        LocalTime time = LocalTime.of(21, 34);	
	        LocalDateTime localDateTime = LocalDateTime.of(date, time);
	        lancamento.setData(localDateTime);
	        lancamento.setDescricao("Serviço prestado");

	        when(lancamentoRepository.save(any(Lancamento.class))).thenReturn(lancamento);

	        Lancamento createdLancamento = lancamentoService.createLancamento(lancamento);
	        assertThat(createdLancamento.getDescricao()).isEqualTo("Serviço prestado");
	    }

	    @Test
	    public void testGetLancamentoById() {
	        Lancamento lancamento = new Lancamento();
	        lancamento.setId(1L);
	        lancamento.setTipo(TipoLancamento.DEBITO);
	        lancamento.setValor(new BigDecimal(75.0));
	        
	        LocalDate date = LocalDate.of(2024, 8, 31);
	        LocalTime time = LocalTime.of(21, 34);	
	        LocalDateTime localDateTime = LocalDateTime.of(date, time);
	        lancamento.setData(localDateTime);
	        lancamento.setDescricao("Compra de escritório");

	        when(lancamentoRepository.findById(anyLong())).thenReturn(Optional.of(lancamento));

	        Lancamento foundLancamento = lancamentoService.getLancamentoById(1L);
	        assertThat(foundLancamento).isNotNull();
	        assertThat(foundLancamento.getTipo()).isEqualTo(TipoLancamento.DEBITO);
	    }

	    @Test
	    public void testGetLancamentosByDate() {
	        Lancamento lancamento = new Lancamento();
	        lancamento.setTipo(TipoLancamento.CREDITO);
	        lancamento.setValor(new BigDecimal(200.0));

	        LocalDate date = LocalDate.of(2024, 8, 31);
	        LocalTime time = LocalTime.of(21, 34);	
	        LocalDateTime localDateTime = LocalDateTime.of(date, time);
	        lancamento.setData(localDateTime);
	        lancamento.setDescricao("Venda de produto");

	        when(lancamentoRepository.findByData(localDateTime))
	                .thenReturn(List.of(lancamento));

	        List<Lancamento> lancamentos = lancamentoService.getLancamentosByDate(LocalDate.of(2024, 8, 31));
	        assertThat(lancamentos).hasSize(1);
	        assertThat(lancamentos.get(0).getDescricao()).isEqualTo("Venda de produto");
	    }

}
