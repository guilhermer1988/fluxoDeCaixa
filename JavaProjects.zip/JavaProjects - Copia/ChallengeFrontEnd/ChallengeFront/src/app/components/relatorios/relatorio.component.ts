import { Component, OnInit } from '@angular/core';
import { RelatorioService } from '../../services/relatorio.service';

@Component({
  selector: 'app-relatorio',
  templateUrl: './relatorio.component.html',
  styleUrls: ['./relatorio.component.scss']
})
export class RelatorioComponent {
  data: string | null = null;
  saldoConsolidado: number = 0;
  errorMessage: string | null = null;

  constructor(private relatorioService: RelatorioService) { }

  ngOnInit(): void {
  }

  onBuscarRelatorio(): void {
    if (this.data) {
      this.relatorioService.getExtractByDate(this.data)
        .subscribe(
          (saldo) => {
            this.saldoConsolidado = saldo;
            this.errorMessage = null;
          },
          (error) => {
            this.errorMessage = 'Erro ao buscar o relatório. Verifique a data e tente novamente.';
            this.saldoConsolidado = 0;
          }
        );
    }
  }

  formatCurrency(value: number): string {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }
}
