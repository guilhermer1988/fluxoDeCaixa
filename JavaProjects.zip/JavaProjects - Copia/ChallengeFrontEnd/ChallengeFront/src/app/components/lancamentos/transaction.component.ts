import { Component, OnInit } from '@angular/core';
import { LancamentoService } from '../../services/lancamento.service';
import { Lancamento } from '../../models/lancamento';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.scss']
})
export class LancamentoComponent implements OnInit {
  newTransaction: Lancamento = new Lancamento();

  constructor(private lancamentoService: LancamentoService) { }

  ngOnInit(): void {
  }

  createTransaction(): void {
    this.lancamentoService.createTransaction(this.newTransaction).subscribe(() => {});
  }

  formatCurrency(value: number): string {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }
}
