import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../utils/constants';

@Injectable({
  providedIn: 'root'
})
export class RelatorioService {
  private apiUrl = `${environment.Relatorio_URL_API}/consolidacaoLoadBalance`;

  constructor(private http: HttpClient) { }

  getExtractByDate(date: string): Observable<number> {
    return this.http.get<number>(`${this.apiUrl}/${date}`);
  }
}
