export const environment = {
    production: false,
    Lancamento_URL_API: 'http://localhost:8090/lancamentos',
    Relatorio_URL_API: 'http://localhost:8888/relatorios',
  };